//
//  Sound.h
//  EmployeeDetail
//
//  Created by Nanthakumar R on 28/09/15.
//  Copyright (c) 2015 sourcebits. All rights reserved.
//

#import <Foundation/Foundation.h>

//typedef NS_ENUM(NSInteger, Animal) {
//    Cat,
//    Dog,
//    Cow
//};

@interface Sound : NSObject
@property (nonatomic) NSString *source;
@property (nonatomic) NSString *soundDescription;

@end
